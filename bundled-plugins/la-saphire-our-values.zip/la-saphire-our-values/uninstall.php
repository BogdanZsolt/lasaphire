<?php

/**
 * Trigger this file on Plugin uninstall
 *
 * @package  LaSaphirePlugin
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	die;
}
