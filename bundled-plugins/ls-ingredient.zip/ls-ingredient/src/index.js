import Filter from './modules/Filter';
import './index.scss';
import './style.scss';

const filter = new Filter();
